# rpi_ad7606

Library for interfacing an Analog Devices AD7606 to a Raspberry Pi. This is so alpha it's not even funny.

## Dependencies

  * pigpio

## Documentation

none yet

## Installation

Clone from source and run

	python setup.py install
